# ANTIGRAVITY — ASSET CHECKLIST

[ ] Create storage buckets/folders for product, service, homepage and gallery media.
[ ] Build admin upload component.
[ ] Allow one main image + multiple gallery images for products.
[ ] Allow image replacement without editing code.
[ ] Store only storage path/URL and metadata in the database.
[ ] Generate/serve responsive sizes when possible.
[ ] Add alt text field.
[ ] Add crop/focal-point support for hero images if feasible.
[ ] Keep source/license information in media metadata when a stock image is used.
[ ] Do not use Unsplash+ assets by mistake when a free asset is required.
[ ] Replace stock product photos with real Divay Beauty product photos before production.
