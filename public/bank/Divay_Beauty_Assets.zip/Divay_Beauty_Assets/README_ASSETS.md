# DIVAY BEAUTY — DOSSIER ASSETS

Ce dossier accompagne le cahier des charges du site Divay Beauty.

## 1. Organisation

- `00_REFERENCE_MAQUETTE` : maquette/référence visuelle.
- `01_HERO` : images principales de la page d'accueil.
- `02_MAKEUP` : maquillage.
- `03_MANUCURE_PEDICURE` : ongles, manucure, pédicure.
- `04_SOINS_VISAGE` : soins visage / skincare.
- `05_SACS_PAGNE` : sacs et tissus pagne/Ankara.
- `06_SACS_PERLES` : sacs perlés.
- `07_EVENTAILS_PAGNE` : éventails.
- `08_PERLES_PERLAGE` : perles, perlage, textures.
- `09_STYLOS_BIJOUX_ACCESSOIRES` : accessoires et petits cadeaux.
- `10_GALERIE` : images lifestyle.
- `11_ICONS_LOGO` : logo et icônes de la marque.
- `12_PLACEHOLDERS` : images temporaires à remplacer par les vraies photos Divay Beauty.

## 2. Règle importante

Les photos de produits vendus par Divay Beauty doivent idéalement être **prises par Divay Beauty** ou fournies par la marque. Les banques d'images servent surtout à la mise en page, aux visuels d'ambiance et aux sections éditoriales.

Pour les vrais produits (sacs, éventails, stylos, etc.), l'équipe doit remplacer les images génériques par des photos originales du stock réel.

## 3. Sources recommandées

Voir `asset_sources.csv`.

Sources principales :
- Unsplash : https://unsplash.com/
- Pexels : https://www.pexels.com/
- Pixabay : https://pixabay.com/

## 4. Consignes de recherche

### Hero
Rechercher une image horizontale 16:9, très lumineuse, avec espace négatif permettant de placer le texte.

Mots-clés :
- luxury beauty salon
- African beauty woman
- makeup beauty editorial
- skincare spa woman
- elegant African woman beauty

### Makeup
- African makeup artist
- African woman makeup
- bridal makeup beauty
- luxury makeup

### Manucure
- manicure salon
- elegant nails
- African woman manicure
- luxury nail care

### Soins du visage
- facial skincare treatment
- African woman facial
- luxury spa skincare

### Pagne / sacs
- Ankara fabric bag
- African print handbag
- African fashion accessories
- wax print handbag

### Perles
- African beaded bag
- handmade beadwork
- beaded accessories
- African beads

### Éventails
- African fabric fan
- Ankara fan
- handmade African fan

## 5. Formats

Préférer :
- WebP pour le site
- JPEG pour les photos
- PNG/SVG pour logos et icônes avec transparence

Tailles recommandées :
- Hero : 1920×1080 ou supérieur
- Bannière : 1600×700 environ
- Cartes produits : 1000×1200 environ
- Produit carré : 1200×1200
- Galerie : 1200×900 ou 1200×1200

## 6. Nommage

Utiliser des noms simples :

hero-main.webp
makeup-mariage-01.webp
manucure-01.webp
soin-visage-01.webp
sac-pagne-elegance-01.webp
sac-perles-royal-01.webp
eventail-pagne-01.webp
stylo-perle-01.webp

Éviter les noms comme IMG_4587.JPG.

## 7. Pour Antigravity

Antigravity doit prévoir une interface d'administration permettant de remplacer les images sans modifier le code.

Les images ne doivent pas être hardcodées dans les composants.

Exemple :
- produit → `main_image_url`
- produit → `product_images`
- prestation → `image_url`
- section accueil → `image_url`
- galerie → table `media`

## 8. Licence

Unsplash indique que ses images peuvent être utilisées gratuitement, y compris commercialement, sans attribution obligatoire, sous réserve de ses restrictions. Voir :
https://unsplash.com/fr/licence

Pexels indique que ses photos/vidéos sont gratuites pour les usages personnels et commerciaux, sans attribution obligatoire, avec des restrictions notamment concernant les personnes, marques et la redistribution à l'identique. Voir :
https://www.pexels.com/fr-fr/license/

Pixabay permet l'utilisation gratuite et la modification de ses contenus sous sa licence, mais impose des restrictions et rappelle que des droits tiers peuvent s'appliquer. Vérifier la page de chaque asset. Voir :
https://pixabay.com/service/license-summary/

## 9. Attention aux personnes et marques

Même lorsqu'une banque d'images autorise l'utilisation commerciale, il faut éviter :
- logos visibles de marques tierces ;
- produits reconnaissables présentés comme ceux de Divay Beauty ;
- image donnant l'impression qu'une personne célèbre ou une marque recommande Divay Beauty ;
- utilisation trompeuse de l'image.

## 10. Priorité

1. Photos originales Divay Beauty pour les produits et réalisations.
2. Photos professionnelles originales du salon et de l'équipe.
3. Photos libres sous licence pour les visuels d'ambiance.
4. Images générées par IA seulement lorsque cela est clairement approprié et que l'équipe valide leur usage.

